<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="[A]Water_pipo" tilewidth="32" tileheight="32" tilecount="3072" columns="64">
 <image source="../pictures/[A]Water_pipo.png" width="2048" height="1536"/>
</tileset>
